/*
 * Elizabeth Johnson
 * johnson_DistanceTraveled
 * 10/2/19
 * This program will calculate distance traveled
 */
package johnson_102_c2a1;

public class Johnson_102_C2A1 
{

    public static void main(String[] args) 
    {
        displayPsuedocode();
        distanceTraveled();
    }
    public static void distanceTraveled()
    {
        final double MPH = 60;
        double fiveHours = MPH * 5;
        double eightHours = MPH * 8;
        double twelveHours = MPH * 12;
        System.out.print("If a car would travel at a constant 60 MPH for five hours, it would travel this many miles: ");
        System.out.println(fiveHours);
        System.out.print("If a car would travel at a constant 60 MPH for eight hours, it would travel this many miles: ");
        System.out.println(eightHours);
        System.out.print("If a car would travel at a constant 60 MPH for twelve hours, it would travel this many miles: ");
        System.out.println(twelveHours);
    }
    
    public static void displayPsuedocode()
    {
        System.out.println("Psuedocode is written here.");
        System.out.println("Declare the four variables: MPH, fiveHours, eightHours, and twelveHours.");
        System.out.println("No input required from the user.");
        System.out.println("60 will be assigned to the variable MPH, and the other variables will be multipled by MPH.");
        System.out.println("The miles covered after each hour at a constant rate of 60 MPH will be displayed.");
        System.out.println();
    }
    
}
