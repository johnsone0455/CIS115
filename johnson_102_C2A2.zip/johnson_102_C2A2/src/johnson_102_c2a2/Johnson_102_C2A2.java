/*
 * Elizabeth Johnson
 * johnson_TipTaxTotal
 * 10/2/19
 * This program will calculate tip, tax, and total
 */
package johnson_102_c2a2;
import java.util.Scanner;
public class Johnson_102_C2A2
{

    public static void main(String[] args) 
    {
        displayPsuedocode();
        TipTaxTotal();
    }
    
    public static void TipTaxTotal()
    {
        Scanner k = new Scanner(System.in);
        System.out.print("Enter the amount of a meal total: ");
        double mealTotal = k.nextDouble();
        final double TIP = .15;
        final double SALESTAX = .07;
        double tipTotal = mealTotal * TIP;
        double taxTotal = mealTotal * SALESTAX;
        double total = mealTotal + tipTotal+ taxTotal;
        System.out.printf("%.2f%n", tipTotal);
        System.out.printf("%.2f%n", taxTotal);
        System.out.printf("%.2f%n", total); 
    }
    
    public static void displayPsuedocode()
    {
        System.out.println("Declare the variables: mealTotal, TIP, SALESTAX, tipTotal, taxTotal, and total.");
        System.out.println("The user is required to enter the meal total.");
        System.out.println("The input from the user is assigned to the variable mealTotal.");
        System.out.println("After calculations to acquire the tipTotal, taxTotal, and total, all three values will be displayed.");
        System.out.println();
    }
}
