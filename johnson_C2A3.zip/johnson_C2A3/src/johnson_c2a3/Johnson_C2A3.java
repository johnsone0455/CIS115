/*
 * Elizabeth Johnson
 * johnson_weightLoss
 * 10/7/19
 * This program will calculate weight loss  
 */
package johnson_c2a3;
import java.util.Scanner;
public class Johnson_C2A3 
{
    
    public static void main(String[] args) 
    {
        displayPsuedocode();
        weightLoss();
    }
    
    public static void weightLoss()
    {
       Scanner k = new Scanner(System.in);
       System.out.print("Please enter your starting weight: ");
       double startWeight = k.nextDouble();
       final double poundsLost = 4;
       double monthOne = startWeight - poundsLost;
       double monthTwo = monthOne - poundsLost;
       double monthThree = monthTwo - poundsLost;
       double monthFour = monthThree - poundsLost;
       double monthFive = monthFour - poundsLost;
       double monthSix = monthFive - poundsLost;
       System.out.println(" Month                        Weight");
       System.out.println("------------------------------------");
       System.out.print("  1                           ");
       System.out.println(monthOne);
       System.out.print("  2                           ");
       System.out.println(monthTwo);
       System.out.print("  3                           ");
       System.out.println(monthThree);
       System.out.print("  4                           ");
       System.out.println(monthFour);
       System.out.print("  5                            ");
       System.out.println(monthFive);
       System.out.print("  6                            ");
       System.out.println(monthSix);
    }
    
    public static void displayPsuedocode()
    {
        System.out.println("Declare the variables: startWeight, poundsLost, and a variable for each month.");
        System.out.println("Input required from user for the variable startWeight.");
        System.out.println("The starting weight entered from the user will be assigned to startWeight.");
        System.out.println("After calculating each weight for the months, the values will be displayed in a table.");
        System.out.println();
    }
}
