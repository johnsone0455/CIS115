/*
 * Elizabeth Johnson
 * johnson_CW930
 * 9/30/19
 * This program will demo modules
 */
package johnson_cw930;
import java.util.Scanner;
public class Johnson_CW930 
{
    public static void main(String[] args) 
    {
        //System.out.println("CW0930");
        displayPsuedocode();
        double num = getInput();
        System.out.println(num);
    }
    public static void  displayPsuedocode()
    {
       System.out.println("CW0930"); 
    }
   public static double getInput()
   {
       Scanner k = new Scanner(System.in);
       System.out.print("Enter your age: ");
       double age = k.nextDouble();
       return age;
   }
    
}
