/*
 * Elizabeth Johnson
 * johnson_PE4
 * 9/25/19
 * This program will calculate a subtotal, tax, and total for ietms purchased
 */
package johnson_pe4;
import java.util.Scanner;
public class Johnson_PE4 
{
  public static void main(String[] args) 
    {
       //System.out.print("PE4");
       Scanner keyboard = new Scanner(System.in);
       System.out.print("Enter the price for the first item: ");
       double item1 = keyboard.nextDouble();
       System.out.print("Enter the price for the second item: ");
       double item2 = keyboard.nextDouble();
       System.out.print("Enter the price for the third item: ");
       double item3 = keyboard.nextDouble();
       System.out.print("Enter the price for the fourth item: ");
       double item4 = keyboard.nextDouble();
       System.out.print("Enter the price for the fifth item: ");
       double item5 = keyboard.nextDouble();
       double subtotal = item1 + item2 + item3 + item4 + item5;
       double salesTax = subtotal * .05;
       double total = subtotal + salesTax;
       System.out.println(subtotal);
       System.out.println(salesTax);
       System.out.println(total);
       
    }
    
}
