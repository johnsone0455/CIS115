/*
 * Elizabeth Johnson
 * johnson_cw923
 * 9-23-19
 * This program will demo java commands
 */
package johnson_cw923;

public class Johnson_cw923 
{

    
    public static void main(String[] args) 
    {
       // code starts here
       System.out.print("Elizabeth ");
       System.out.println("Johnson");
    }
    
}
